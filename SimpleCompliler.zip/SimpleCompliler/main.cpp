#include <iostream>
#include <string>
#include <cctype>
#include <stdexcept>

using namespace std;

class Parser {
    string expr;
    size_t pos;

public:
    Parser(const string& s) : expr(s), pos(0) {}

    double parse() {
        double result = parseExpression();
        skipWhitespace();
        if (pos < expr.length()) {
            throw runtime_error("Unexpected character at end of input.");
        }
        return result;
    }

private:
    void skipWhitespace() {
        while (pos < expr.length() && isspace(expr[pos])) pos++;
    }

    double parseNumber() {
        skipWhitespace();
        size_t start = pos;
        bool dotFound = false;

        while (pos < expr.length() && (isdigit(expr[pos]) || expr[pos] == '.')) {
            if (expr[pos] == '.') {
                if (dotFound) break;
                dotFound = true;
            }
            pos++;
        }

        if (start == pos) throw runtime_error("Expected number.");
        return stod(expr.substr(start, pos - start));
    }

    double parseFactor() {
        skipWhitespace();

        if (expr[pos] == '(') {
            pos++; // skip '('
            double val = parseExpression();
            skipWhitespace();
            if (expr[pos] != ')') throw runtime_error("Missing closing parenthesis.");
            pos++; // skip ')'
            return val;
        }

        return parseNumber();
    }

    double parseTerm() {
        double val = parseFactor();
        while (true) {
            skipWhitespace();
            if (pos >= expr.length()) break;

            char op = expr[pos];
            if (op != '*' && op != '/') break;
            pos++;

            double nextVal = parseFactor();
            if (op == '*') val *= nextVal;
            else {
                if (nextVal == 0) throw runtime_error("Division by zero.");
                val /= nextVal;
            }
        }
        return val;
    }

    double parseExpression() {
        double val = parseTerm();
        while (true) {
            skipWhitespace();
            if (pos >= expr.length()) break;

            char op = expr[pos];
            if (op != '+' && op != '-') break;
            pos++;

            double nextVal = parseTerm();
            if (op == '+') val += nextVal;
            else val -= nextVal;
        }
        return val;
    }
};

int main() {
    cout << "Enter an arithmetic expression (e.g., 2 + 3 * (4 - 1)):" << endl;
    string input;
    getline(cin, input);

    try {
        Parser parser(input);
        double result = parser.parse();
        cout << "Result: " << result << endl;
    } catch (const exception& ex) {
        cerr << "Error: " << ex.what() << endl;
    }

    cout << "Press Enter to exit..." << endl;
    cin.get();
    return 0;
}